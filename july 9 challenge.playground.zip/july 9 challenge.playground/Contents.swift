import UIKit


func numberOfVowels(in string: String) -> Int {
    var numberOfVowels = 0
    for vowel in string {
        switch vowel {
        case "a", "A", "e", "E", "i", "I", "o", "O", "u", "U":
            numberOfVowels = numberOfVowels + 1
        default:
            break
        }
     
    }
   // print(numberOfVowels)
    return numberOfVowels

}



print(numberOfVowels(in: "Who said that"))
print(numberOfVowels(in: "Nobody move"))
print(numberOfVowels(in: "Somewhere over the rainbow"))
